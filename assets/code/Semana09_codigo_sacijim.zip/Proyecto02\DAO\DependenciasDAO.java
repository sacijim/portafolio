package DAO;

import Modelo.ProyectoModelo;
import Modelo.TareaModelo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Analiza las dependencias entre tareas con recursividad (recorrido en profundidad del grafo). */
public class DependenciasDAO {

    private final ProyectoModelo proyecto;

    public DependenciasDAO(ProyectoModelo proyecto) {
        this.proyecto = proyecto;
    }

    // ---------------------------------------------------------------- RF01
    public void registrarTarea(String codigo, String descripcion, boolean completada) {
        if (codigo.isEmpty() || descripcion.isEmpty()) {
            throw new IllegalArgumentException("El codigo y la descripcion no pueden estar vacios.");
        }
        if (proyecto.getTareasPorCodigo().containsKey(codigo)) {
            throw new IllegalArgumentException("Ya existe la tarea " + codigo + ".");
        }
        proyecto.getTareasPorCodigo().put(codigo, new TareaModelo(codigo, descripcion, completada));
    }

    // ---------------------------------------------------------------- RF02
    /** La tarea {@code codigoTarea} necesita que {@code codigoPrerrequisito} termine primero. */
    public void registrarDependencia(String codigoTarea, String codigoPrerrequisito) {
        TareaModelo tarea = obtenerTarea(codigoTarea);
        obtenerTarea(codigoPrerrequisito);
        if (codigoTarea.equals(codigoPrerrequisito)) {
            throw new IllegalArgumentException("Una tarea no puede depender de si misma.");
        }
        if (tarea.getCodigosPrerrequisitos().contains(codigoPrerrequisito)) {
            throw new IllegalArgumentException("La dependencia " + codigoTarea + " -> " + codigoPrerrequisito + " ya existe.");
        }
        tarea.getCodigosPrerrequisitos().add(codigoPrerrequisito);
    }

    // ---------------------------------------------------------------- RF03
    public List<String> consultarDependenciasDirectas(String codigoTarea) {
        return new ArrayList<>(obtenerTarea(codigoTarea).getCodigosPrerrequisitos());
    }

    // ---------------------------------------------------------------- RF04
    /** Todas las dependencias indirectas: prerrequisitos de los prerrequisitos, y asi sucesivamente. */
    public Set<String> dependenciasIndirectas(String codigoTarea) {
        Set<String> encontradas = new LinkedHashSet<>();
        recopilarPrerrequisitos(codigoTarea, encontradas);
        return encontradas;
    }

    private void recopilarPrerrequisitos(String codigoTarea, Set<String> encontradas) {
        for (String codigoPrerrequisito : obtenerTarea(codigoTarea).getCodigosPrerrequisitos()) {
            if (encontradas.add(codigoPrerrequisito)) {          // si ya estaba, no se vuelve a recorrer
                recopilarPrerrequisitos(codigoPrerrequisito, encontradas);
            }
        }
    }

    // ---------------------------------------------------------------- RF05
    /** Longitud de la cadena mas larga de prerrequisitos (0 si la tarea no depende de nadie). */
    public int profundidadMaxima(String codigoTarea) {
        obtenerTarea(codigoTarea);
        if (!detectarCiclo().isEmpty()) {
            throw new IllegalStateException("Hay un ciclo de dependencias; la profundidad no esta definida.");
        }
        return profundidad(codigoTarea);
    }

    private int profundidad(String codigoTarea) {
        List<String> prerrequisitos = obtenerTarea(codigoTarea).getCodigosPrerrequisitos();
        if (prerrequisitos.isEmpty()) {
            return 0;                                           // caso base: tarea sin prerrequisitos
        }
        return 1 + nivelMasProfundo(prerrequisitos, 0, 0);
    }

    /**
     * Recursividad anidada: el resultado de profundidad(...) (llamada interior) se usa como
     * argumento de Math.max(...), y este valor es el argumento de la llamada recursiva exterior.
     */
    private int nivelMasProfundo(List<String> prerrequisitos, int indice, int mayorNivel) {
        if (indice == prerrequisitos.size()) {
            return mayorNivel;                                  // caso base: ya se revisaron todos
        }
        return nivelMasProfundo(prerrequisitos, indice + 1,
                Math.max(mayorNivel, profundidad(prerrequisitos.get(indice))));
    }

    // ---------------------------------------------------------------- RF06
    /** Devuelve la ruta del primer ciclo encontrado (ej. [A, B, C, A]) o una lista vacia si no hay. */
    public List<String> detectarCiclo() {
        Set<String> terminadas = new HashSet<>();
        for (String codigoTarea : proyecto.getTareasPorCodigo().keySet()) {
            List<String> ruta = new ArrayList<>();
            if (buscarCiclo(codigoTarea, ruta, terminadas)) {
                return ruta;
            }
        }
        return new ArrayList<>();
    }

    private boolean buscarCiclo(String codigoTarea, List<String> ruta, Set<String> terminadas) {
        int posicionEnRuta = ruta.indexOf(codigoTarea);
        if (posicionEnRuta >= 0) {                              // volvimos a una tarea que esta explorandose
            ruta.subList(0, posicionEnRuta).clear();
            ruta.add(codigoTarea);
            return true;
        }
        if (terminadas.contains(codigoTarea)) {
            return false;
        }
        ruta.add(codigoTarea);
        for (String codigoPrerrequisito : obtenerTarea(codigoTarea).getCodigosPrerrequisitos()) {
            if (buscarCiclo(codigoPrerrequisito, ruta, terminadas)) {
                return true;
            }
        }
        ruta.remove(ruta.size() - 1);
        terminadas.add(codigoTarea);
        return false;
    }

    // ---------------------------------------------------------------- RF07
    /** Tareas pendientes que tienen al menos un prerrequisito sin completar. */
    public List<String> tareasBloqueadas() {
        List<String> bloqueadas = new ArrayList<>();
        for (TareaModelo tarea : proyecto.getTareasPorCodigo().values()) {
            if (!tarea.isCompletada() && tienePrerrequisitoPendiente(tarea)) {
                bloqueadas.add(tarea.getCodigo());
            }
        }
        return bloqueadas;
    }

    private boolean tienePrerrequisitoPendiente(TareaModelo tarea) {
        for (String codigoPrerrequisito : tarea.getCodigosPrerrequisitos()) {
            if (!obtenerTarea(codigoPrerrequisito).isCompletada()) {
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- RF08
    public String generarReporte() {
        int completadas = 0;
        int pendientes = 0;
        for (TareaModelo tarea : proyecto.getTareasPorCodigo().values()) {
            if (tarea.isCompletada()) {
                completadas++;
            } else {
                pendientes++;
            }
        }
        return "Completadas: " + completadas + " | Pendientes: " + pendientes
                + " | Bloqueadas: " + tareasBloqueadas().size();
    }

    // ---------------------------------------------------------------- apoyo
    public Collection<TareaModelo> listarTareas() {
        return proyecto.getTareasPorCodigo().values();
    }

    public TareaModelo obtenerTarea(String codigoTarea) {
        TareaModelo tarea = proyecto.getTareasPorCodigo().get(codigoTarea);
        if (tarea == null) {
            throw new IllegalArgumentException("No existe la tarea " + codigoTarea + ".");
        }
        return tarea;
    }
}
