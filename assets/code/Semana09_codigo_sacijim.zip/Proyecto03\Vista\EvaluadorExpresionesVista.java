package Vista;

import DAO.EvaluadorExpresionesDAO;
import Modelo.ExpresionModelo;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** Menu de consola del Proyecto 03: varias evaluaciones en una misma sesion. */
public class EvaluadorExpresionesVista {

    private final Scanner lectorTeclado = new Scanner(System.in);
    private final EvaluadorExpresionesDAO dao = new EvaluadorExpresionesDAO();
    private final List<ExpresionModelo> historialSesion = new ArrayList<>();

    public void iniciar() {
        int opcionElegida;
        do {
            System.out.println("\n=== EVALUADOR DE REGLAS COMERCIALES ===");
            System.out.println("[1] Evaluar expresion   [2] Precio final Pf = (Pb - D) x (1 + I)");
            System.out.println("[3] Validar expresion   [4] Historial de la sesion   [0] Salir");
            opcionElegida = leerEntero("Opcion: ");
            switch (opcionElegida) {
                case 1: evaluarYMostrar(leerTexto("Expresion: ")); break;
                case 2: opcionPrecioFinal(); break;
                case 3: opcionValidar(); break;
                case 4: opcionHistorial(); break;
                case 0: System.out.println("Fin del programa."); break;
                default: System.out.println("Opcion no valida.");
            }
        } while (opcionElegida != 0);
    }

    private void evaluarYMostrar(String textoExpresion) {
        ExpresionModelo expresionModelo = new ExpresionModelo(textoExpresion);
        try {
            dao.evaluar(expresionModelo);
            historialSesion.add(expresionModelo);
            System.out.println("Expresion: " + expresionModelo.getTextoExpresion());
            System.out.println("Resultado: " + expresionModelo.getResultado());
        } catch (IllegalArgumentException errorValidacion) {
            System.out.println("Error: " + errorValidacion.getMessage());
        }
    }

    private void opcionPrecioFinal() {
        String precioBase = leerTexto("Precio base Pb: ");
        String descuentoMonetario = leerTexto("Descuento D: ");
        String tasaImpuesto = leerTexto("Tasa de impuesto I (ej. 0.18): ");
        evaluarYMostrar("(" + precioBase + "-" + descuentoMonetario + ")*(1+" + tasaImpuesto + ")");
    }

    private void opcionValidar() {
        String motivoError = dao.validar(leerTexto("Expresion a validar: "));
        System.out.println(motivoError == null ? "Expresion valida." : "Expresion invalida: " + motivoError);
    }

    private void opcionHistorial() {
        if (historialSesion.isEmpty()) {
            System.out.println("Todavia no hay evaluaciones en esta sesion.");
        }
        for (int indice = 0; indice < historialSesion.size(); indice++) {
            ExpresionModelo expresionModelo = historialSesion.get(indice);
            System.out.println((indice + 1) + ") " + expresionModelo.getTextoExpresion() + " = " + expresionModelo.getResultado());
        }
    }

    private String leerTexto(String mensajeSolicitud) {
        System.out.print(mensajeSolicitud);
        return lectorTeclado.nextLine().trim();
    }

    private int leerEntero(String mensajeSolicitud) {
        try {
            return Integer.parseInt(leerTexto(mensajeSolicitud));
        } catch (NumberFormatException errorFormato) {
            return -1;
        }
    }
}
