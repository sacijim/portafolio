package Vista;

import DAO.DependenciasDAO;
import Modelo.ProyectoModelo;
import Modelo.TareaModelo;
import java.util.List;
import java.util.Scanner;

/** Menu de consola del Proyecto 02: pide los datos, llama al DAO y muestra los resultados. */
public class DependenciasVista {

    private final Scanner lectorTeclado = new Scanner(System.in);
    private final DependenciasDAO dao = new DependenciasDAO(new ProyectoModelo());

    public void iniciar() {
        int opcionElegida;
        do {
            mostrarMenu();
            opcionElegida = leerEntero("Opcion: ");
            try {
                switch (opcionElegida) {
                    case 1: opcionRegistrarTarea(); break;
                    case 2: opcionRegistrarDependencia(); break;
                    case 3: opcionDependenciasDirectas(); break;
                    case 4: opcionDependenciasIndirectas(); break;
                    case 5: opcionProfundidad(); break;
                    case 6: opcionDetectarCiclo(); break;
                    case 7: opcionTareasBloqueadas(); break;
                    case 8: System.out.println(dao.generarReporte()); break;
                    case 9: opcionCargarEjemplo(); break;
                    case 0: System.out.println("Fin del programa."); break;
                    default: System.out.println("Opcion no valida.");
                }
            } catch (IllegalArgumentException | IllegalStateException excepcion) {
                System.out.println("Error: " + excepcion.getMessage());
            }
        } while (opcionElegida != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n=== DEPENDENCIAS DE TAREAS ===");
        System.out.println("[1] Registrar tarea          [2] Registrar dependencia");
        System.out.println("[3] Dependencias directas    [4] Dependencias indirectas");
        System.out.println("[5] Profundidad de cadena    [6] Detectar ciclos");
        System.out.println("[7] Tareas bloqueadas        [8] Reporte");
        System.out.println("[9] Cargar datos de ejemplo  [0] Salir");
    }

    private void opcionRegistrarTarea() {
        String codigoTarea = leerTexto("Codigo: ");
        String descripcionTarea = leerTexto("Descripcion: ");
        String estadoIngresado = leerTexto("Esta completada? (s/n): ");
        dao.registrarTarea(codigoTarea, descripcionTarea, estadoIngresado.equalsIgnoreCase("s"));
        System.out.println("Tarea registrada: " + codigoTarea);
    }

    private void opcionRegistrarDependencia() {
        String codigoTarea = leerTexto("Tarea que depende: ");
        String codigoPrerrequisito = leerTexto("Prerrequisito: ");
        dao.registrarDependencia(codigoTarea, codigoPrerrequisito);
        System.out.println("Dependencia registrada: " + codigoTarea + " -> " + codigoPrerrequisito);
    }

    private void opcionDependenciasDirectas() {
        String codigoTarea = leerTexto("Codigo de la tarea: ");
        System.out.println("Directas de " + codigoTarea + ": " + dao.consultarDependenciasDirectas(codigoTarea));
    }

    private void opcionDependenciasIndirectas() {
        String codigoTarea = leerTexto("Codigo de la tarea: ");
        System.out.println("Todas las dependencias de " + codigoTarea + ": " + dao.dependenciasIndirectas(codigoTarea));
    }

    private void opcionProfundidad() {
        String codigoTarea = leerTexto("Codigo de la tarea: ");
        System.out.println("Profundidad maxima de " + codigoTarea + ": " + dao.profundidadMaxima(codigoTarea));
    }

    private void opcionDetectarCiclo() {
        List<String> rutaCiclo = dao.detectarCiclo();
        System.out.println(rutaCiclo.isEmpty() ? "Sin ciclos: la planificacion es valida." : "CICLO detectado: " + rutaCiclo);
    }

    private void opcionTareasBloqueadas() {
        List<String> tareasBloqueadas = dao.tareasBloqueadas();
        System.out.println(tareasBloqueadas.isEmpty() ? "No hay tareas bloqueadas." : "Bloqueadas: " + tareasBloqueadas);
    }

    /** Carga el proyecto de ejemplo del enunciado (autenticacion, clientes, inventario, ventas...). */
    private void opcionCargarEjemplo() {
        dao.registrarTarea("AUT-01", "Autenticacion", true);
        dao.registrarTarea("CLI-02", "Modulo de clientes", true);
        dao.registrarTarea("INV-03", "Modulo de inventario", false);
        dao.registrarTarea("VEN-04", "Modulo de ventas", false);
        dao.registrarTarea("REP-05", "Modulo de reportes", false);
        dao.registrarTarea("PRU-06", "Pruebas de integracion", false);
        dao.registrarDependencia("CLI-02", "AUT-01");
        dao.registrarDependencia("INV-03", "AUT-01");
        dao.registrarDependencia("VEN-04", "CLI-02");
        dao.registrarDependencia("VEN-04", "INV-03");
        dao.registrarDependencia("REP-05", "VEN-04");
        dao.registrarDependencia("PRU-06", "VEN-04");
        dao.registrarDependencia("PRU-06", "REP-05");
        System.out.println("Datos de ejemplo cargados: " + dao.listarTareas().size() + " tareas.");
        for (TareaModelo tarea : dao.listarTareas()) {
            System.out.println("  " + tarea.getCodigo() + " " + tarea.getDescripcion() + " [" + tarea.getEstado() + "]");
        }
    }

    private String leerTexto(String mensajeSolicitud) {
        System.out.print(mensajeSolicitud);
        return lectorTeclado.nextLine().trim();
    }

    private int leerEntero(String mensajeSolicitud) {
        try {
            return Integer.parseInt(leerTexto(mensajeSolicitud));
        } catch (NumberFormatException errorFormato) {
            return -1;
        }
    }
}
