package Vista;

/** Punto de entrada del Proyecto 02. */
public class Principal {

    public static void main(String[] args) {
        new DependenciasVista().iniciar();
    }
}
