package Vista;

import DAO.CostosProductosDAO;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/** Menu de consola del Proyecto 04. */
public class CostosProductosVista {

    private final Scanner lectorTeclado = new Scanner(System.in);
    private final CostosProductosDAO dao = new CostosProductosDAO();

    public void iniciar() {
        int opcionElegida;
        do {
            System.out.println("\n=== COSTOS DE PRODUCTOS COMPUESTOS ===");
            System.out.println("[1] Registrar producto     [2] Agregar componente");
            System.out.println("[3] Costo total            [4] Desglose por niveles");
            System.out.println("[5] Componentes compartidos [6] Reporte de costos");
            System.out.println("[9] Cargar datos de ejemplo [0] Salir");
            opcionElegida = leerEntero("Opcion: ");
            try {
                switch (opcionElegida) {
                    case 1: opcionRegistrarProducto(); break;
                    case 2: opcionAgregarComponente(); break;
                    case 3: opcionCostoTotal(); break;
                    case 4: opcionDesglose(); break;
                    case 5: opcionCompartidos(); break;
                    case 6: System.out.print(dao.generarReporte()); break;
                    case 9: opcionCargarEjemplo(); break;
                    case 0: System.out.println("Fin del programa."); break;
                    default: System.out.println("Opcion no valida.");
                }
            } catch (IllegalArgumentException | ArithmeticException excepcion) {
                System.out.println("Error: " + excepcion.getMessage());
            }
        } while (opcionElegida != 0);
    }

    private void opcionRegistrarProducto() {
        String codigoProducto = leerTexto("Codigo: ");
        String nombreProducto = leerTexto("Nombre: ");
        BigDecimal costoUnitario = leerDecimal("Costo unitario (S/): ");
        dao.registrarProducto(codigoProducto, nombreProducto, costoUnitario);
        System.out.println("Producto registrado: " + codigoProducto);
    }

    private void opcionAgregarComponente() {
        String codigoProducto = leerTexto("Producto: ");
        String codigoComponente = leerTexto("Componente: ");
        int cantidadRequerida = leerEntero("Cantidad requerida: ");
        dao.agregarComponente(codigoProducto, codigoComponente, cantidadRequerida);
        System.out.println(codigoProducto + " ahora contiene " + cantidadRequerida + " x " + codigoComponente);
    }

    private void opcionCostoTotal() {
        String codigoProducto = leerTexto("Codigo del producto: ");
        System.out.println("Costo total de " + codigoProducto + ": S/ " + dao.costoTotal(codigoProducto).setScale(2));
    }

    private void opcionDesglose() {
        String codigoProducto = leerTexto("Codigo del producto: ");
        System.out.print(dao.desglosarCostos(codigoProducto, 1, 0));
    }

    private void opcionCompartidos() {
        Map<String, List<String>> compartidos = dao.componentesCompartidos();
        if (compartidos.isEmpty()) {
            System.out.println("No hay componentes compartidos.");
        }
        compartidos.forEach((componente, productos) ->
                System.out.println(componente + " lo usan: " + productos));
    }

    /** Carga el ejemplo: computador y servidor comparten placa, memoria y fuente. */
    private void opcionCargarEjemplo() {
        dao.registrarProducto("CHIP-06", "Chip procesador", new BigDecimal("25.00"));
        dao.registrarProducto("CAPA-07", "Capacitor", new BigDecimal("0.50"));
        dao.registrarProducto("RAM-03", "Modulo de memoria", new BigDecimal("60.00"));
        dao.registrarProducto("FUEN-05", "Fuente de alimentacion", new BigDecimal("45.00"));
        dao.registrarProducto("PLAC-02", "Placa electronica", new BigDecimal("40.00"));
        dao.registrarProducto("SSD-04", "Unidad de almacenamiento", new BigDecimal("30.00"));
        dao.registrarProducto("PC-01", "Computador", new BigDecimal("50.00"));
        dao.registrarProducto("SERV-08", "Servidor", new BigDecimal("80.00"));
        dao.agregarComponente("PLAC-02", "CHIP-06", 1);
        dao.agregarComponente("PLAC-02", "CAPA-07", 20);
        dao.agregarComponente("SSD-04", "CHIP-06", 1);
        dao.agregarComponente("PC-01", "PLAC-02", 1);
        dao.agregarComponente("PC-01", "RAM-03", 2);
        dao.agregarComponente("PC-01", "SSD-04", 1);
        dao.agregarComponente("PC-01", "FUEN-05", 1);
        dao.agregarComponente("SERV-08", "PLAC-02", 2);
        dao.agregarComponente("SERV-08", "RAM-03", 8);
        dao.agregarComponente("SERV-08", "FUEN-05", 2);
        System.out.println("Datos de ejemplo cargados: " + dao.listarProductos().size() + " productos.");
    }

    private String leerTexto(String mensajeSolicitud) {
        System.out.print(mensajeSolicitud);
        return lectorTeclado.nextLine().trim();
    }

    private int leerEntero(String mensajeSolicitud) {
        try {
            return Integer.parseInt(leerTexto(mensajeSolicitud));
        } catch (NumberFormatException errorFormato) {
            return -1;
        }
    }

    private BigDecimal leerDecimal(String mensajeSolicitud) {
        try {
            return new BigDecimal(leerTexto(mensajeSolicitud));
        } catch (NumberFormatException errorFormato) {
            throw new IllegalArgumentException("El costo debe ser un numero.");
        }
    }
}
