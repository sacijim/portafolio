package DAO;

import Modelo.ExpresionModelo;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * Evaluador por descenso recursivo. Gramatica:
 *   expresion := termino  { (+|-) termino }
 *   termino   := factor   { (*|/) factor }
 *   factor    := numero | '(' expresion ')' | '-' factor
 * expresion() llama a termino(), termino() a factor() y factor() vuelve a llamar a expresion()
 * dentro de los parentesis: asi se evaluan las expresiones anidadas.
 */
public class EvaluadorExpresionesDAO {

    private String textoSinEspacios;
    private int posicionActual;

    public void evaluar(ExpresionModelo expresionModelo) {
        textoSinEspacios = expresionModelo.getTextoExpresion().replace(" ", "");
        posicionActual = 0;
        if (textoSinEspacios.isEmpty()) {
            throw new IllegalArgumentException("La expresion esta vacia.");
        }
        BigDecimal resultado = expresion();
        if (posicionActual < textoSinEspacios.length()) {
            char sobrante = textoSinEspacios.charAt(posicionActual);
            throw new IllegalArgumentException(sobrante == ')'
                    ? "Parentesis de cierre sin apertura en la posicion " + (posicionActual + 1) + "."
                    : "Simbolo inesperado '" + sobrante + "' en la posicion " + (posicionActual + 1) + ".");
        }
        expresionModelo.setResultado(resultado.setScale(2, RoundingMode.HALF_UP));
    }

    /** RF10: valida sin guardar nada; devuelve null si la expresion es correcta o el motivo del error. */
    public String validar(String textoExpresion) {
        try {
            evaluar(new ExpresionModelo(textoExpresion));
            return null;
        } catch (IllegalArgumentException errorValidacion) {
            return errorValidacion.getMessage();
        }
    }

    /** Procesa sumas y restas. */
    private BigDecimal expresion() {
        BigDecimal acumulado = termino();
        while (hayOperador('+') || hayOperador('-')) {
            char operador = textoSinEspacios.charAt(posicionActual++);
            BigDecimal siguienteTermino = termino();
            acumulado = (operador == '+') ? acumulado.add(siguienteTermino)
                                          : acumulado.subtract(siguienteTermino);
        }
        return acumulado;
    }

    /** Procesa multiplicaciones y divisiones (tienen mas precedencia que + y -). */
    private BigDecimal termino() {
        BigDecimal acumulado = factor();
        while (hayOperador('*') || hayOperador('/')) {
            char operador = textoSinEspacios.charAt(posicionActual++);
            BigDecimal siguienteFactor = factor();
            if (operador == '*') {
                acumulado = acumulado.multiply(siguienteFactor);
            } else {
                if (siguienteFactor.signum() == 0) {
                    throw new IllegalArgumentException("Division por cero.");
                }
                acumulado = acumulado.divide(siguienteFactor, MathContext.DECIMAL64);
            }
        }
        return acumulado;
    }

    /** Procesa numeros, signo negativo y parentesis; dentro del parentesis vuelve a llamar a expresion(). */
    private BigDecimal factor() {
        if (posicionActual >= textoSinEspacios.length()) {
            throw new IllegalArgumentException(
                    "La expresion termina antes de tiempo: falta un operando.");
        }
        char caracterActual = textoSinEspacios.charAt(posicionActual);
        if (caracterActual == '-') {
            posicionActual++;
            return factor().negate();
        }
        if (caracterActual == '(') {
            int posicionApertura = posicionActual + 1;
            posicionActual++;
            BigDecimal valorInterior = expresion();
            if (!hayOperador(')')) {
                throw new IllegalArgumentException(
                        "Parentesis sin cerrar (abierto en la posicion "
                        + posicionApertura + ").");
            }
            posicionActual++;
            return valorInterior;
        }
        return numero();
    }

    private BigDecimal numero() {
        int posicionInicio = posicionActual;
        while (posicionActual < textoSinEspacios.length()
                && (Character.isDigit(textoSinEspacios.charAt(posicionActual)) || textoSinEspacios.charAt(posicionActual) == '.')) {
            posicionActual++;
        }
        if (posicionInicio == posicionActual) {
            throw new IllegalArgumentException("Se esperaba un numero en la posicion " + (posicionActual + 1)
                    + " y se encontro '" + textoSinEspacios.charAt(posicionActual) + "'.");
        }
        try {
            return new BigDecimal(textoSinEspacios.substring(posicionInicio, posicionActual));
        } catch (NumberFormatException errorNumero) {
            throw new IllegalArgumentException("Numero mal formado: " + textoSinEspacios.substring(posicionInicio, posicionActual) + ".");
        }
    }

    private boolean hayOperador(char operadorBuscado) {
        return posicionActual < textoSinEspacios.length() && textoSinEspacios.charAt(posicionActual) == operadorBuscado;
    }
}
