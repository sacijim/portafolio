package DAO;

import Modelo.ComponenteModelo;
import Modelo.ProductoModelo;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Calcula el costo de fabricacion recorriendo recursivamente la estructura jerarquica de cada producto. */
public class CostosProductosDAO {

    private final Map<String, ProductoModelo> productosPorCodigo = new LinkedHashMap<>();

    // ------------------------------------------------------ RF01, RF02, RF09
    public void registrarProducto(String codigo, String nombre, BigDecimal costoUnitario) {
        if (codigo.isEmpty() || nombre.isEmpty()) {
            throw new IllegalArgumentException("El codigo y el nombre no pueden estar vacios.");
        }
        if (costoUnitario.signum() < 0) {
            throw new IllegalArgumentException("El costo no puede ser negativo.");
        }
        if (productosPorCodigo.containsKey(codigo)) {
            throw new IllegalArgumentException("Ya existe el producto " + codigo + ".");
        }
        productosPorCodigo.put(codigo, new ProductoModelo(codigo, nombre, costoUnitario));
    }

    // ------------------------------------------------------ RF03, RF04, RF08, RF09
    public void agregarComponente(String codigoProducto, String codigoComponente, int cantidadRequerida) {
        ProductoModelo producto = obtenerProducto(codigoProducto);
        obtenerProducto(codigoComponente);
        if (cantidadRequerida <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }
        if (codigoProducto.equals(codigoComponente)) {
            throw new IllegalArgumentException("Un producto no puede contenerse a si mismo.");
        }
        if (contieneComponente(codigoComponente, codigoProducto)) {
            throw new IllegalArgumentException("Ciclo: " + codigoComponente + " ya contiene a " + codigoProducto + ".");
        }
        producto.getComponentes().add(new ComponenteModelo(codigoComponente, cantidadRequerida));
    }

    /** RF08: true si {@code codigoBuscado} aparece en cualquier nivel dentro de {@code codigoRaiz}. */
    public boolean contieneComponente(String codigoRaiz, String codigoBuscado) {
        for (ComponenteModelo componente : obtenerProducto(codigoRaiz).getComponentes()) {
            if (componente.getCodigoComponente().equals(codigoBuscado)
                    || contieneComponente(componente.getCodigoComponente(), codigoBuscado)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------ RF05
    /** Costo total = costo propio + suma de (cantidad x costo total) de cada componente. */
    public BigDecimal costoTotal(String codigoProducto) {
        ProductoModelo producto = obtenerProducto(codigoProducto);
        return sumarComponentes(producto.getComponentes(), 0, producto.getCostoUnitario());
    }

    /**
     * Recursividad anidada: costoTotal(...) (llamada interior) calcula el costo de un componente y su
     * resultado, multiplicado por la cantidad, se usa dentro del argumento de la llamada exterior.
     */
    private BigDecimal sumarComponentes(List<ComponenteModelo> componentes, int indice, BigDecimal acumulado) {
        if (indice == componentes.size()) {
            return acumulado;                                   // caso base: no quedan componentes
        }
        ComponenteModelo componente = componentes.get(indice);
        return sumarComponentes(componentes, indice + 1,
                acumulado.add(costoTotal(componente.getCodigoComponente())
                        .multiply(BigDecimal.valueOf(componente.getCantidadRequerida()))));
    }

    // ------------------------------------------------------ RF06
    /** Desglose por niveles: cada nivel se sangra con dos espacios mas. */
    public String desglosarCostos(String codigoProducto, int cantidad, int nivel) {
        ProductoModelo producto = obtenerProducto(codigoProducto);
        StringBuilder desglose = new StringBuilder();
        desglose.append("  ".repeat(nivel)).append(cantidad).append(" x ").append(producto.getNombre())
                .append(" (").append(codigoProducto).append(")  costo total ").append(costoTotal(codigoProducto)
                        .multiply(BigDecimal.valueOf(cantidad)).setScale(2)).append('\n');
        for (ComponenteModelo componente : producto.getComponentes()) {
            desglose.append(desglosarCostos(componente.getCodigoComponente(), componente.getCantidadRequerida(), nivel + 1));
        }
        return desglose.toString();
    }

    // ------------------------------------------------------ RF07
    /** Componentes usados directamente por dos o mas productos distintos. */
    public Map<String, List<String>> componentesCompartidos() {
        Map<String, List<String>> usadoPor = new LinkedHashMap<>();
        for (ProductoModelo producto : productosPorCodigo.values()) {
            for (ComponenteModelo componente : producto.getComponentes()) {
                usadoPor.computeIfAbsent(componente.getCodigoComponente(), c -> new ArrayList<>()).add(producto.getCodigo());
            }
        }
        usadoPor.values().removeIf(productos -> productos.size() < 2);
        return usadoPor;
    }

    // ------------------------------------------------------ RF10
    /** Productos terminados: los que no son componente de ningun otro. */
    public String generarReporte() {
        StringBuilder reporte = new StringBuilder();
        for (ProductoModelo producto : productosPorCodigo.values()) {
            if (!esComponenteDeOtro(producto.getCodigo())) {
                reporte.append(producto.getNombre()).append(" (").append(producto.getCodigo())
                        .append("): S/ ").append(costoTotal(producto.getCodigo()).setScale(2)).append('\n');
            }
        }
        return reporte.toString();
    }

    private boolean esComponenteDeOtro(String codigoProducto) {
        for (ProductoModelo producto : productosPorCodigo.values()) {
            for (ComponenteModelo componente : producto.getComponentes()) {
                if (componente.getCodigoComponente().equals(codigoProducto)) {
                    return true;
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------ apoyo
    public Collection<ProductoModelo> listarProductos() { return productosPorCodigo.values(); }

    public ProductoModelo obtenerProducto(String codigoProducto) {
        ProductoModelo producto = productosPorCodigo.get(codigoProducto);
        if (producto == null) {
            throw new IllegalArgumentException("No existe el producto " + codigoProducto + ".");
        }
        return producto;
    }
}
