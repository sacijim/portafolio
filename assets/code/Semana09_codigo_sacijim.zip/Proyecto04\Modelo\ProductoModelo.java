package Modelo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Producto o componente. costoUnitario es lo que cuesta por si solo (compra o ensamblaje), sin sus partes. */
public class ProductoModelo {

    private final String codigo;
    private final String nombre;
    private final BigDecimal costoUnitario;
    private final List<ComponenteModelo> componentes = new ArrayList<>();

    public ProductoModelo(String codigo, String nombre, BigDecimal costoUnitario) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.costoUnitario = costoUnitario;
    }

    public String getCodigo() { return codigo; }

    public String getNombre() { return nombre; }

    public BigDecimal getCostoUnitario() { return costoUnitario; }

    public List<ComponenteModelo> getComponentes() { return componentes; }
}
