package Vista;

/** Punto de entrada del Proyecto 03. */
public class Principal {

    public static void main(String[] args) {
        new EvaluadorExpresionesVista().iniciar();
    }
}
