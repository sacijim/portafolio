package Modelo;

import java.math.BigDecimal;

/** Una expresion comercial escrita por el usuario y el resultado de evaluarla. */
public class ExpresionModelo {

    private final String textoExpresion;
    private BigDecimal resultado;

    public ExpresionModelo(String textoExpresion) {
        this.textoExpresion = textoExpresion;
    }

    public String getTextoExpresion() { return textoExpresion; }

    public BigDecimal getResultado() { return resultado; }

    public void setResultado(BigDecimal resultado) { this.resultado = resultado; }
}
