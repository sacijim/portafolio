package Vista;

/** Punto de entrada del Proyecto 04. */
public class Principal {

    public static void main(String[] args) {
        new CostosProductosVista().iniciar();
    }
}
