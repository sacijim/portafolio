package Modelo;

/** Relacion "producto contiene componente": el codigo del componente y cuantas unidades se necesitan. */
public class ComponenteModelo {

    private final String codigoComponente;
    private final int cantidadRequerida;

    public ComponenteModelo(String codigoComponente, int cantidadRequerida) {
        this.codigoComponente = codigoComponente;
        this.cantidadRequerida = cantidadRequerida;
    }

    public String getCodigoComponente() { return codigoComponente; }

    public int getCantidadRequerida() { return cantidadRequerida; }
}
