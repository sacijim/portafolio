package Modelo;

import java.util.LinkedHashMap;
import java.util.Map;

/** Guarda las tareas del proyecto; cada tarea apunta a sus prerrequisitos por codigo (grafo dirigido). */
public class ProyectoModelo {

    private final Map<String, TareaModelo> tareasPorCodigo = new LinkedHashMap<>();

    public Map<String, TareaModelo> getTareasPorCodigo() { return tareasPorCodigo; }
}
